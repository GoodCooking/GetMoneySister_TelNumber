﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 获取富婆电话
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //富婆加密
        private void btnEncrypts_Click(object sender, EventArgs e)
        {
            if (WomanOrgionTel.Text.Length == 0)
            {
                MessageBox.Show("姐姐，你没有输入手机号欸😘。", "姐姐😘");
                return;
            }
            string telNo = WomanOrgionTel.Text;

            List<int> intList = telNo.Select(digit => int.Parse(digit.ToString())).ToList().Distinct().ToList();
            List<int> telList = telNo.Select(digit => int.Parse(digit.ToString())).ToList();
            List<int> list = new List<int>();

            telList.ForEach(p =>
            {
                list.Add(intList.FindIndex(q => q == p));
            }
            );
            foreach (int i in list)
            {
                //Console.Write(i);
            }
            string womanShortTel = "";
            for (int i = 0; i < intList.Count; i++)
            {
                womanShortTel = womanShortTel + intList[i] + ",";
            }
            WomanShortTel.Text = womanShortTel;

            string womanEncryptsInfo = "";
            for (int i = 0; i < list.Count; i++)
            {
                womanEncryptsInfo = womanEncryptsInfo + list[i] + ",";
            }
            WomanEncryptsInfo.Text = womanEncryptsInfo;
        }

        //获取富婆手机号
        private void btnGet_Click(object sender, EventArgs e)
        {
            if (GetWomanShortTel.Text.Length == 0)
            {
                MessageBox.Show("输入短号啊，垃圾！", "垃圾👎！！！");
                //return;
            }
            if (GetWomanEncryptsInfo.TextLength == 0)
            {
                MessageBox.Show("输入加密的信息啊，垃圾，真逊👎", "垃圾！！！");
            }

            string womanShortTel = GetWomanShortTel.Text.Replace(",", "").Replace("，", "");
            List<int> womanShortTelList = womanShortTel.Select(digit => int.Parse(digit.ToString())).ToList();//转成list<int>

            string getWomanEncryptsInfo = GetWomanEncryptsInfo.Text.Replace(",", "").Replace("，", "");
            List<int> getWomanEncryptsInfoList = getWomanEncryptsInfo.Select(digit => int.Parse(digit.ToString())).ToList();//转成list<int>
            string tel = "";
            for (int i = 0; i < getWomanEncryptsInfoList.Count; i++)
            {
                tel += (womanShortTelList[getWomanEncryptsInfoList[i]]);
            }
            GetWomanTel.Text = tel;
        }

        private void WomanOrgionTel_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(e.KeyChar == '\b' || (e.KeyChar >=
                '0' && e.KeyChar <= '9')))
            {
                e.Handled = true;
            }
        }
    }
}
//祝有情人终成眷属
//我暴富就行