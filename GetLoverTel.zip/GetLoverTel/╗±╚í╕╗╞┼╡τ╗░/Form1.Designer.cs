﻿
namespace 获取富婆电话
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnEncrypts = new System.Windows.Forms.Button();
            this.btnGet = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.WomanOrgionTel = new System.Windows.Forms.TextBox();
            this.GetWomanShortTel = new System.Windows.Forms.TextBox();
            this.GetWomanEncryptsInfo = new System.Windows.Forms.TextBox();
            this.GetWomanTel = new System.Windows.Forms.TextBox();
            this.WomanShortTel = new System.Windows.Forms.TextBox();
            this.WomanEncryptsInfo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.WomanEncryptsInfo);
            this.groupBox1.Controls.Add(this.WomanShortTel);
            this.groupBox1.Controls.Add(this.WomanOrgionTel);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnEncrypts);
            this.groupBox1.Location = new System.Drawing.Point(48, 104);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(287, 231);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "我是富婆，";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.GetWomanTel);
            this.groupBox2.Controls.Add(this.GetWomanEncryptsInfo);
            this.groupBox2.Controls.Add(this.GetWomanShortTel);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.btnGet);
            this.groupBox2.Location = new System.Drawing.Point(378, 110);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(340, 225);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "姐姐的信息";
            // 
            // btnEncrypts
            // 
            this.btnEncrypts.Location = new System.Drawing.Point(159, 199);
            this.btnEncrypts.Name = "btnEncrypts";
            this.btnEncrypts.Size = new System.Drawing.Size(80, 32);
            this.btnEncrypts.TabIndex = 2;
            this.btnEncrypts.Text = "加密";
            this.btnEncrypts.UseVisualStyleBackColor = true;
            this.btnEncrypts.Click += new System.EventHandler(this.btnEncrypts_Click);
            // 
            // btnGet
            // 
            this.btnGet.Location = new System.Drawing.Point(201, 193);
            this.btnGet.Name = "btnGet";
            this.btnGet.Size = new System.Drawing.Size(83, 32);
            this.btnGet.TabIndex = 0;
            this.btnGet.Text = "获取手机号";
            this.btnGet.UseVisualStyleBackColor = true;
            this.btnGet.Click += new System.EventHandler(this.btnGet_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "输入手机号：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "姐姐短号：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "姐姐的加密信息：";
            // 
            // WomanOrgionTel
            // 
            this.WomanOrgionTel.Location = new System.Drawing.Point(101, 47);
            this.WomanOrgionTel.Name = "WomanOrgionTel";
            this.WomanOrgionTel.Size = new System.Drawing.Size(161, 21);
            this.WomanOrgionTel.TabIndex = 4;
            this.WomanOrgionTel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.WomanOrgionTel_KeyPress);
            // 
            // GetWomanShortTel
            // 
            this.GetWomanShortTel.Location = new System.Drawing.Point(118, 41);
            this.GetWomanShortTel.Name = "GetWomanShortTel";
            this.GetWomanShortTel.Size = new System.Drawing.Size(166, 21);
            this.GetWomanShortTel.TabIndex = 3;
            // 
            // GetWomanEncryptsInfo
            // 
            this.GetWomanEncryptsInfo.Location = new System.Drawing.Point(118, 95);
            this.GetWomanEncryptsInfo.Name = "GetWomanEncryptsInfo";
            this.GetWomanEncryptsInfo.Size = new System.Drawing.Size(166, 21);
            this.GetWomanEncryptsInfo.TabIndex = 4;
            // 
            // GetWomanTel
            // 
            this.GetWomanTel.Location = new System.Drawing.Point(118, 152);
            this.GetWomanTel.Name = "GetWomanTel";
            this.GetWomanTel.Size = new System.Drawing.Size(166, 21);
            this.GetWomanTel.TabIndex = 5;
            // 
            // WomanShortTel
            // 
            this.WomanShortTel.Location = new System.Drawing.Point(101, 107);
            this.WomanShortTel.Name = "WomanShortTel";
            this.WomanShortTel.Size = new System.Drawing.Size(161, 21);
            this.WomanShortTel.TabIndex = 5;
            // 
            // WomanEncryptsInfo
            // 
            this.WomanEncryptsInfo.Location = new System.Drawing.Point(101, 158);
            this.WomanEncryptsInfo.Name = "WomanEncryptsInfo";
            this.WomanEncryptsInfo.Size = new System.Drawing.Size(161, 21);
            this.WomanEncryptsInfo.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 161);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "姐姐的手机号：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 110);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 12);
            this.label5.TabIndex = 7;
            this.label5.Text = "手机号短号：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 167);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 12);
            this.label6.TabIndex = 8;
            this.label6.Text = "加密信息：";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "获取姐姐电话||姐姐电话号加密 v1.0";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox WomanEncryptsInfo;
        private System.Windows.Forms.TextBox WomanShortTel;
        private System.Windows.Forms.TextBox WomanOrgionTel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnEncrypts;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox GetWomanTel;
        private System.Windows.Forms.TextBox GetWomanEncryptsInfo;
        private System.Windows.Forms.TextBox GetWomanShortTel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnGet;
    }
}

